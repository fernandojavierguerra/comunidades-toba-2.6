<?php

class toba_mc_item__3495
{
	static function get_metadatos()
	{
		return array (
  'basica' => 
  array (
    'item_proyecto' => 'comunidades',
    'item' => '3495',
    'item_nombre' => 'Comunidades',
    'item_descripcion' => NULL,
    'item_act_buffer_proyecto' => NULL,
    'item_act_buffer' => NULL,
    'item_act_patron_proyecto' => NULL,
    'item_act_patron' => NULL,
    'item_act_accion_script' => NULL,
    'item_solic_tipo' => 'web',
    'item_solic_registrar' => NULL,
    'item_solic_obs_tipo_proyecto' => NULL,
    'item_solic_obs_tipo' => NULL,
    'item_solic_observacion' => NULL,
    'item_solic_cronometrar' => NULL,
    'item_parametro_a' => NULL,
    'item_parametro_b' => NULL,
    'item_parametro_c' => NULL,
    'item_imagen_recurso_origen' => NULL,
    'item_imagen' => NULL,
    'punto_montaje' => NULL,
    'tipo_pagina_clase' => 'toba_tp_normal',
    'tipo_pagina_archivo' => '',
    'item_include_arriba' => NULL,
    'item_include_abajo' => NULL,
    'item_zona_proyecto' => NULL,
    'item_zona' => NULL,
    'zona_punto_montaje' => NULL,
    'item_zona_archivo' => NULL,
    'zona_cons_archivo' => NULL,
    'zona_cons_clase' => NULL,
    'zona_cons_metodo' => NULL,
    'item_publico' => NULL,
    'item_existe_ayuda' => NULL,
    'carpeta' => NULL,
    'menu' => 1,
    'orden' => '0',
    'publico' => NULL,
    'redirecciona' => NULL,
    'crono' => NULL,
    'solicitud_tipo' => 'web',
    'item_padre' => '3493',
    'cant_dependencias' => '1',
    'cant_items_hijos' => '0',
    'molde' => '27',
    'retrasar_headers' => 0,
  ),
  'objetos' => 
  array (
    0 => 
    array (
      'objeto_proyecto' => 'comunidades',
      'objeto' => '2454',
      'objeto_nombre' => 'Comunidades - CI',
      'objeto_subclase' => 'ci_comunidades',
      'objeto_subclase_archivo' => 'comunidades/ci_comunidades.php',
      'orden' => 0,
      'clase_proyecto' => 'toba',
      'clase' => 'toba_ci',
      'clase_archivo' => 'nucleo/componentes/interface/toba_ci.php',
      'fuente_proyecto' => 'comunidades',
      'fuente' => 'comunidades',
      'fuente_motor' => 'postgres7',
      'fuente_host' => NULL,
      'fuente_usuario' => NULL,
      'fuente_clave' => NULL,
      'fuente_base' => NULL,
    ),
  ),
);
	}

}

?>