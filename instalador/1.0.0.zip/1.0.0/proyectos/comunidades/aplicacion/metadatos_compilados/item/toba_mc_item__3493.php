<?php

class toba_mc_item__3493
{
	static function get_metadatos()
	{
		return array (
  'basica' => 
  array (
    'item_proyecto' => 'comunidades',
    'item' => '3493',
    'item_nombre' => 'Configuracion',
    'item_descripcion' => NULL,
    'item_act_buffer_proyecto' => NULL,
    'item_act_buffer' => NULL,
    'item_act_patron_proyecto' => NULL,
    'item_act_patron' => NULL,
    'item_act_accion_script' => NULL,
    'item_solic_tipo' => NULL,
    'item_solic_registrar' => NULL,
    'item_solic_obs_tipo_proyecto' => NULL,
    'item_solic_obs_tipo' => NULL,
    'item_solic_observacion' => NULL,
    'item_solic_cronometrar' => NULL,
    'item_parametro_a' => NULL,
    'item_parametro_b' => NULL,
    'item_parametro_c' => NULL,
    'item_imagen_recurso_origen' => 'apex',
    'item_imagen' => NULL,
    'punto_montaje' => NULL,
    'tipo_pagina_clase' => NULL,
    'tipo_pagina_archivo' => NULL,
    'item_include_arriba' => NULL,
    'item_include_abajo' => NULL,
    'item_zona_proyecto' => NULL,
    'item_zona' => NULL,
    'zona_punto_montaje' => NULL,
    'item_zona_archivo' => NULL,
    'zona_cons_archivo' => NULL,
    'zona_cons_clase' => NULL,
    'zona_cons_metodo' => NULL,
    'item_publico' => NULL,
    'item_existe_ayuda' => NULL,
    'carpeta' => 1,
    'menu' => 1,
    'orden' => '100',
    'publico' => NULL,
    'redirecciona' => NULL,
    'crono' => NULL,
    'solicitud_tipo' => NULL,
    'item_padre' => '1',
    'cant_dependencias' => '0',
    'cant_items_hijos' => '6',
    'molde' => NULL,
    'retrasar_headers' => 0,
  ),
  'objetos' => 
  array (
  ),
);
	}

}

?>