<?php

class toba_mc_gene__pms
{
	static function get_pms()
	{
		return array (
  0 => 
  array (
    'id' => '16',
    'etiqueta' => 'proyecto',
    'proyecto' => 'comunidades',
    'proyecto_ref' => 'comunidades',
    'descripcion' => 'Punto de montaje por defecto de todos los proyectos de toba',
    'path_pm' => 'php',
    'tipo' => 'proyecto_toba',
  ),
);
	}

}

?>