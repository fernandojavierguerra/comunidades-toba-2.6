<?php

class toba_mc_gene__relacion_tablas_comunidades
{
	static function get_info()
	{
		return array (
);
	}

}

?>