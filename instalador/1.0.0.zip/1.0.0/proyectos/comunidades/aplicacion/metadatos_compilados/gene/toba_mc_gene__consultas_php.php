<?php

class toba_mc_gene__consultas_php
{
}

?>