<?php

class toba_mc_gene__items_publicos
{
	static function get_items_accesibles()
	{
		return array (
  'comunidades-3492' => 
  array (
    'proyecto' => 'comunidades',
    'item' => '3492',
  ),
);
	}

}

?>