<?php

class toba_mc_gene__msj_proyecto
{
}

?>