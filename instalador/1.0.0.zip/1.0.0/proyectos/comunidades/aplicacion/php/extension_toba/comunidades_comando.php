<?php

class comunidades_comando extends toba_aplicacion_comando_base 
{
			
}

?>