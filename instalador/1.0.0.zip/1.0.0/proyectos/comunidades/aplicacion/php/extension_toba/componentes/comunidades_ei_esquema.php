<?php
class comunidades_ei_esquema extends toba_ei_esquema
{
}
?>