<?php
class comunidades_ei_archivos extends toba_ei_archivos
{
}
?>