<?php
class comunidades_ei_mapa extends toba_ei_mapa
{
}
?>