<?php
class comunidades_ei_cuadro extends toba_ei_cuadro
{
}
?>