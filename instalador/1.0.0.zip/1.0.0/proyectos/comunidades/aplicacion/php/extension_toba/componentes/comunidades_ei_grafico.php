<?php
class comunidades_ei_grafico extends toba_ei_grafico
{
}
?>