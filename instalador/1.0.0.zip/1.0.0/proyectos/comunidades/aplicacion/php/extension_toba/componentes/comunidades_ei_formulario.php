<?php
class comunidades_ei_formulario extends toba_ei_formulario
{
}
?>