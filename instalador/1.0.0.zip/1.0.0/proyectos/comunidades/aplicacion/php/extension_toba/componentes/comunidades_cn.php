<?php
class comunidades_cn extends toba_cn
{
}
?>