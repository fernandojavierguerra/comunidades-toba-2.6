<?php
class comunidades_ei_firma extends toba_ei_firma
{
}
?>