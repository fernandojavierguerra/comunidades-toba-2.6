<?php
class comunidades_servicio_web extends toba_servicio_web
{
}
?>