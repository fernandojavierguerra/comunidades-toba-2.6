<?php

class comunidades_modelo extends toba_aplicacion_modelo_base 
{

}

?>