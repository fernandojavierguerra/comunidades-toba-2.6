<?php
class comunidades_datos_tabla extends toba_datos_tabla
{
}
?>