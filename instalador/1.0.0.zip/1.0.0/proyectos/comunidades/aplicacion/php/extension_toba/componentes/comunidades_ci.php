<?php
class comunidades_ci extends toba_ci
{
}
?>