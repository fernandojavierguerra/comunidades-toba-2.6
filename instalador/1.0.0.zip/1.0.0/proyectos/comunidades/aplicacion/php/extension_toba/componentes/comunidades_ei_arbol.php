<?php
class comunidades_ei_arbol extends toba_ei_arbol
{
}
?>