<?php
class comunidades_datos_relacion extends toba_datos_relacion
{
}
?>