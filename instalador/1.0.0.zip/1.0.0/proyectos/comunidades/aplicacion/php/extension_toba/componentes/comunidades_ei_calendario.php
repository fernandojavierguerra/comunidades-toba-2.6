<?php
class comunidades_ei_calendario extends toba_ei_calendario
{
}
?>