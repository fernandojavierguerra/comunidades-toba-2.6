
------------------------------------------------------------
-- apex_usuario_perfil_datos
------------------------------------------------------------

--- INICIO Grupo de desarrollo 0
INSERT INTO apex_usuario_perfil_datos (proyecto, usuario_perfil_datos, nombre, descripcion, listar) VALUES (
	'comunidades', --proyecto
	'8', --usuario_perfil_datos
	'Exploradores', --nombre
	'Exploradores', --descripcion
	NULL  --listar
);
--- FIN Grupo de desarrollo 0
