
------------------------------------------------------------
-- apex_usuario_perfil_datos_dims
------------------------------------------------------------

--- INICIO Grupo de desarrollo 0
INSERT INTO apex_usuario_perfil_datos_dims (proyecto, usuario_perfil_datos, dimension, elemento, clave) VALUES (
	'comunidades', --proyecto
	'8', --usuario_perfil_datos
	'14', --dimension
	'27', --elemento
	'2'  --clave
);
--- FIN Grupo de desarrollo 0
