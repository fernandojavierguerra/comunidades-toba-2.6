<?php

class paso_diagnosticar_inicial extends paso
{
	function conf()
	{
		$this->opcional = true;
		$this->nombre = 'Bienvenida';
	}
}
?>