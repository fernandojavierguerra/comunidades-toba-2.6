<h1>Envio Satisfactorio</h1>
<p>
Se ha enviado correctamente un mail con el resultado del correo a <strong><?php echo inst::accion()->paso('2')->get_correo_destino(); ?></strong>. 
Presione cerrar ventana para continuar.

	<div class="go">
		<span class="goToNext">
			<a href="javascript: window.close();">Cerrar Ventana</a>
		</span>
	</div>
