<?php
	include(INST_DIR.'/lib/templates_comunes/requisitos.php');
?>