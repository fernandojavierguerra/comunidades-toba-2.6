<?php

class paso_actualizarparcial_requisitos extends paso_requisitos_base
{
}

?>