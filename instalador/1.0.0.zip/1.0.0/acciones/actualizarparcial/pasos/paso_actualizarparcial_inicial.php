<?php

class paso_actualizarparcial_inicial extends paso
{
	function conf()
	{
		$this->opcional = true;
		$this->nombre = 'Bienvenida';
	}
}
?>