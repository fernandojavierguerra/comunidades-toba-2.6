<?php

class paso_actualizar_inicial extends paso
{
	function conf()
	{
		$this->opcional = true;
		$this->nombre = 'Bienvenida';
	}
}
?>