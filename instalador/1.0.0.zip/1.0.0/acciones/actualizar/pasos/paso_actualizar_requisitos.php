<?php

class paso_actualizar_requisitos extends paso_requisitos_base
{
}

?>