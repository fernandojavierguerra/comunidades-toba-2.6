<?php

class paso_instalar_requisitos extends paso_requisitos_base
{
}

?>