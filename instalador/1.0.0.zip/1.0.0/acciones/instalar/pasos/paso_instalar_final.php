<?php

class paso_instalar_final extends paso
{
	function conf()
	{
		$this->opcional = true;
		$this->completo = true;
		$this->nombre = 'Finalizaci�n';
	}
}
?>